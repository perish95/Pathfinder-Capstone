package com.example.capstone;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import static android.R.layout.simple_list_item_1;

public class FriendActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.activity_friend);

        String[] items = {"버너스리", "장노이만", "박욘베", "킴선동", "안산피앙세", "우산피앙세"};
        ListAdapter adapter = new ArrayAdapter<String>(this, simple_list_item_1, items);
        ListView listView = (ListView) findViewById(R.id.friendListView);
        listView.setAdapter(adapter);

        /*listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                String item = String.valueOf(parent.getItemAtPosition(i));
                Toast.makeText(FriendActivity.this, item, Toast.LENGTH_SHORT).show();
            }
        });*/
    }
}
