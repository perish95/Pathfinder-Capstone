package com.example.capstone;

import java.io.Serializable;

public class Member implements Serializable {
    private int _number;
    private String _id;
    private String _password;
    private String _name;

    Member(String number, String id, String password, String name){
        _number = Integer.parseInt(number);
        _id = id;
        _password = password;
        _name = name;
    }

    public String getId(){
        return _id;
    }

    public String get_password(){
        return _password;
    }
}
